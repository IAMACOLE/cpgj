//
//  SlotMachineTableViewCell.h
//  KKSlotMachineView
//
//  Created by hello on 2018/3/13.
//  Copyright © 2018年 hello. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DefineDataHeader.h"

@interface SlotMachineTableViewCell : UITableViewCell

@property(nonatomic,copy)NSString *titleString;

@end
